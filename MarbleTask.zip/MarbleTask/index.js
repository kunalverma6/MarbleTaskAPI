const express = require("express");
const { Pool } = require("pg");
const swaggerUi = require("swagger-ui-express");
const YAML = require("yamljs");
const app = express();

app.use(express.json());

// PostgreSQL Pool Configuration
const pool = new Pool({
  user: "postgres",
  host: "43.204.246.102",
  database: "DigitalLink",
  password: "P@ssw0rd",
  port: 5432,
});
//"DefaultConnection": "Server=43.204.246.102;Port=5432;Database=DigitalLink;User Id=postgres;Password=P@ssw0rd;Pooling=true;"
// Routes
app.post("/notes", async (req, res) => {
  try {
    const { title, body } = req.body;
    const result = await pool.query("SELECT * FROM create_note($1, $2)", [
      title,
      body,
    ]);
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: "Failed to create note" });
  }
});

app.get("/notes/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query("SELECT * FROM get_note_by_id($1)", [id]);
    if (result.rows.length > 0) {
      res.json(result.rows[0]);
    } else {
      res.status(404).json({ error: "Note not found" });
    }
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch note" });
  }
});

app.get("/notes", async (req, res) => {
  try {
    const { title } = req.query;
    const result = await pool.query("SELECT * FROM query_notes_by_title($1)", [
      title || "",
    ]);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: "Failed to query notes" });
  }
});

app.put("/notes/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { title, body } = req.body;
    const result = await pool.query("SELECT * FROM update_note($1, $2, $3)", [
      id,
      title,
      body,
    ]);
    if (result.rows.length > 0) {
      res.json(result.rows[0]);
    } else {
      res.status(404).json({ error: "Note not found" });
    }
  } catch (error) {
    res.status(500).json({ error: "Failed to update note" });
  }
});

// Swagger UI
const swaggerDocument = YAML.load("./swagger.yaml");
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocument));

app.listen(3000, () => {
  console.log("Server running on port 3000");
});
