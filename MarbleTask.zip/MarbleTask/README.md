#

git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin "https://github.com/kunalverma6/MarbleTaskAPI.git"
git push -u origin main
